# jQuery MessageBox

A jQuery Plugin to replace Javascript's window.alert(), window.confirm() and window.prompt() functions

---

Documentation and examples at https://gasparesganga.com/labs/jquery-message-box/
